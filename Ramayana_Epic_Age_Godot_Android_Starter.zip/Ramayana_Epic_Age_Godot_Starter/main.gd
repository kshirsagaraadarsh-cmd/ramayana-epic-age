extends Node3D

const TREE_COUNT := 48
var hero: CharacterBody3D
var camera_pivot: Node3D
var camera: Camera3D
var joystick_origin := Vector2.ZERO
var joystick_vector := Vector2.ZERO
var joystick_active := false
var look_touch_id := -1
var last_look := Vector2.ZERO
var yaw := 0.0
var pitch := -0.18
var mission_done := false
var target: StaticBody3D
var status_label: Label
var joy_base: ColorRect
var joy_knob: ColorRect

func _ready() -> void:
    _build_world()
    _build_hero()
    _build_ui()
    _set_status("MISSION 01: Reach the forest shrine and strike the training target.")

func _build_world() -> void:
    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_SKY
    environment.sky = Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.10, 0.22, 0.34)
    sky_mat.sky_horizon_color = Color(0.78, 0.68, 0.48)
    sky_mat.ground_bottom_color = Color(0.12, 0.16, 0.12)
    sky_mat.ground_horizon_color = Color(0.48, 0.42, 0.29)
    environment.sky.sky_material = sky_mat
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.58, 0.62, 0.68)
    environment.ambient_light_energy = 0.7
    environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.environment = environment
    add_child(env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_energy = 1.5
    sun.shadow_enabled = true
    add_child(sun)

    var ground := StaticBody3D.new()
    ground.name = "ForestGround"
    var mesh := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(150, 150)
    mesh.mesh = plane
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.18, 0.27, 0.16)
    mat.roughness = 1.0
    mesh.material_override = mat
    ground.add_child(mesh)
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(150, 0.3, 150)
    shape.shape = box
    shape.position.y = -0.15
    ground.add_child(shape)
    add_child(ground)

    # Winding sandy trail
    for i in range(12):
        var step := MeshInstance3D.new()
        var sm := BoxMesh.new()
        sm.size = Vector3(3.5, 0.06, 2.5)
        step.mesh = sm
        var sand := StandardMaterial3D.new()
        sand.albedo_color = Color(0.42, 0.32, 0.19)
        step.material_override = sand
        step.position = Vector3(0, 0.04, -i * 4.5)
        add_child(step)

    # Procedural trees, kept simple for mobile rendering
    for i in range(TREE_COUNT):
        var x := randf_range(-42, 42)
        var z := randf_range(-55, 28)
        if abs(x) < 5.0 and z < 3 and z > -52:
            continue
        _make_tree(Vector3(x, 0, z))

    _make_shrine(Vector3(0, 0, -43))
    _make_target(Vector3(4.5, 0, -26))
    _make_rocks()

func _make_tree(pos: Vector3) -> void:
    var trunk := MeshInstance3D.new()
    var cylinder := CylinderMesh.new()
    cylinder.top_radius = 0.22
    cylinder.bottom_radius = 0.42
    cylinder.height = randf_range(3.2, 5.0)
    trunk.mesh = cylinder
    var bark := StandardMaterial3D.new()
    bark.albedo_color = Color(0.22, 0.13, 0.075)
    trunk.material_override = bark
    trunk.position = pos + Vector3.UP * cylinder.height * 0.5
    add_child(trunk)
    var crown := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = randf_range(1.5, 2.3)
    sphere.height = sphere.radius * 1.8
    crown.mesh = sphere
    var leaves := StandardMaterial3D.new()
    leaves.albedo_color = Color(0.10 + randf() * 0.06, 0.23 + randf() * 0.10, 0.11)
    leaves.roughness = 1.0
    crown.material_override = leaves
    crown.position = pos + Vector3.UP * (cylinder.height + 1.1)
    add_child(crown)

func _make_shrine(pos: Vector3) -> void:
    var base := _box_visual(Vector3(5, 0.5, 4), Color(0.55, 0.43, 0.27), pos + Vector3(0, 0.25, 0))
    var pillar_mat := Color(0.68, 0.54, 0.33)
    for x in [-1.8, 1.8]:
        for z in [-1.2, 1.2]:
            _box_visual(Vector3(0.35, 3.2, 0.35), pillar_mat, pos + Vector3(x, 1.85, z))
    _box_visual(Vector3(4.5, 0.45, 3.4), Color(0.62, 0.47, 0.27), pos + Vector3(0, 3.55, 0))
    _box_visual(Vector3(2.5, 1.3, 2.2), Color(0.48, 0.32, 0.19), pos + Vector3(0, 4.35, 0))
    var glow := OmniLight3D.new()
    glow.position = pos + Vector3(0, 2.0, 0)
    glow.light_color = Color(1.0, 0.63, 0.25)
    glow.light_energy = 1.2
    glow.omni_range = 9
    add_child(glow)

func _make_target(pos: Vector3) -> void:
    target = StaticBody3D.new()
    target.position = pos
    var post := MeshInstance3D.new()
    var pole := CylinderMesh.new()
    pole.top_radius = 0.12
    pole.bottom_radius = 0.12
    pole.height = 2.8
    post.mesh = pole
    post.position.y = 1.4
    var wood := StandardMaterial3D.new()
    wood.albedo_color = Color(0.28, 0.16, 0.08)
    post.material_override = wood
    target.add_child(post)
    var disk := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.85
    sphere.height = 0.25
    disk.mesh = sphere
    disk.position = Vector3(0, 2.2, 0)
    var red := StandardMaterial3D.new()
    red.albedo_color = Color(0.68, 0.12, 0.08)
    disk.material_override = red
    target.add_child(disk)
    var collision := CollisionShape3D.new()
    var cs := SphereShape3D.new()
    cs.radius = 1.0
    collision.shape = cs
    collision.position = Vector3(0, 2.2, 0)
    target.add_child(collision)
    target.add_to_group("training_target")
    add_child(target)

func _make_rocks() -> void:
    for i in range(18):
        var rock := MeshInstance3D.new()
        var sphere := SphereMesh.new()
        sphere.radius = randf_range(0.35, 1.0)
        sphere.height = sphere.radius * 1.2
        rock.mesh = sphere
        var stone := StandardMaterial3D.new()
        stone.albedo_color = Color(0.25, 0.27, 0.23)
        rock.material_override = stone
        rock.position = Vector3(randf_range(-38, 38), sphere.radius * 0.35, randf_range(-48, 25))
        add_child(rock)

func _box_visual(size: Vector3, color: Color, pos: Vector3) -> MeshInstance3D:
    var m := MeshInstance3D.new()
    var b := BoxMesh.new()
    b.size = size
    m.mesh = b
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.roughness = 0.9
    m.material_override = material
    m.position = pos
    add_child(m)
    return m

func _build_hero() -> void:
    hero = CharacterBody3D.new()
    hero.name = "ShriRam"
    hero.position = Vector3(0, 1.0, 5)
    var capsule := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.42
    cap.height = 1.9
    capsule.shape = cap
    capsule.position.y = 0.95
    hero.add_child(capsule)

    # Temporary stylized placeholder body; replace with a licensed/custom 3D hero model.
    var body := MeshInstance3D.new()
    var body_mesh := CapsuleMesh.new()
    body_mesh.radius = 0.42
    body_mesh.height = 1.65
    body.mesh = body_mesh
    var skin := StandardMaterial3D.new()
    skin.albedo_color = Color(0.18, 0.36, 0.62)
    body.material_override = skin
    body.position.y = 1.05
    hero.add_child(body)
    var head := MeshInstance3D.new()
    var head_mesh := SphereMesh.new()
    head_mesh.radius = 0.28
    head_mesh.height = 0.56
    head.mesh = head_mesh
    head.material_override = skin
    head.position = Vector3(0, 2.05, 0)
    hero.add_child(head)
    var sash := _hero_box(hero, Vector3(0.12, 1.0, 0.12), Color(0.85, 0.56, 0.13), Vector3(0.32, 1.05, 0))
    sash.rotation_degrees.z = -18
    add_child(hero)

    camera_pivot = Node3D.new()
    camera_pivot.position = Vector3(0, 1.6, 0)
    hero.add_child(camera_pivot)
    camera = Camera3D.new()
    camera.position = Vector3(0, 2.0, 6.5)
    camera.look_at_from_position(camera.position, Vector3.ZERO, Vector3.UP)
    camera.current = true
    camera_pivot.add_child(camera)

func _hero_box(parent: Node3D, size: Vector3, color: Color, pos: Vector3) -> MeshInstance3D:
    var m := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    m.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    m.material_override = mat
    m.position = pos
    parent.add_child(m)
    return m

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(root)

    status_label = Label.new()
    status_label.position = Vector2(24, 22)
    status_label.size = Vector2(760, 80)
    status_label.add_theme_font_size_override("font_size", 22)
    status_label.add_theme_color_override("font_color", Color(1.0, 0.9, 0.65))
    status_label.add_theme_color_override("font_shadow_color", Color.BLACK)
    status_label.add_theme_constant_override("shadow_offset_x", 2)
    status_label.add_theme_constant_override("shadow_offset_y", 2)
    root.add_child(status_label)

    joy_base = ColorRect.new()
    joy_base.color = Color(0.1, 0.12, 0.14, 0.48)
    joy_base.size = Vector2(150, 150)
    joy_base.position = Vector2(45, -195)
    joy_base.anchor_top = 1
    joy_base.anchor_bottom = 1
    root.add_child(joy_base)
    joy_knob = ColorRect.new()
    joy_knob.color = Color(0.85, 0.78, 0.58, 0.8)
    joy_knob.size = Vector2(58, 58)
    joy_knob.position = Vector2(46, 46)
    joy_base.add_child(joy_knob)

    var fire := _make_button(root, "SHOOT", Vector2(-175, -155), Vector2(130, 76))
    fire.pressed.connect(_fire_arrow)
    var jump := _make_button(root, "JUMP", Vector2(-175, -65), Vector2(110, 62))
    jump.pressed.connect(_jump)
    var shrine := _make_button(root, "SHRINE", Vector2(-305, -65), Vector2(110, 62))
    shrine.pressed.connect(_check_shrine)

    var hint := Label.new()
    hint.text = "DRAG RIGHT SIDE TO LOOK"
    hint.anchor_left = 1
    hint.anchor_right = 1
    hint.position = Vector2(-300, 20)
    hint.size = Vector2(280, 35)
    hint.add_theme_font_size_override("font_size", 14)
    hint.add_theme_color_override("font_color", Color(1, 1, 1, 0.7))
    root.add_child(hint)

func _make_button(parent: Control, text_value: String, offset: Vector2, size_value: Vector2) -> Button:
    var b := Button.new()
    b.text = text_value
    b.size = size_value
    b.anchor_left = 1
    b.anchor_right = 1
    b.anchor_top = 1
    b.anchor_bottom = 1
    b.position = offset
    b.add_theme_font_size_override("font_size", 18)
    b.modulate = Color(1, 0.88, 0.65, 0.92)
    parent.add_child(b)
    return b

func _set_status(message: String) -> void:
    if status_label:
        status_label.text = message

func _process(delta: float) -> void:
    if not is_instance_valid(hero):
        return
    var move := Vector3(joystick_vector.x, 0, joystick_vector.y)
    if move.length() > 0.08:
        var direction := (Basis(Vector3.UP, yaw) * move).normalized()
        hero.velocity.x = direction.x * 5.2
        hero.velocity.z = direction.z * 5.2
        hero.rotation.y = lerp_angle(hero.rotation.y, atan2(-direction.x, -direction.z), delta * 9.0)
    else:
        hero.velocity.x = move_toward(hero.velocity.x, 0, 18 * delta)
        hero.velocity.z = move_toward(hero.velocity.z, 0, 18 * delta)
    if not hero.is_on_floor():
        hero.velocity.y -= 20.0 * delta
    hero.move_and_slide()
    camera_pivot.rotation.y = yaw
    camera_pivot.rotation.x = pitch

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < get_viewport().get_visible_rect().size.x * 0.42 and event.position.y > get_viewport().get_visible_rect().size.y * 0.48:
                joystick_active = true
                joystick_origin = joy_base.global_position + joy_base.size * 0.5
                _update_joystick(event.position)
            else:
                look_touch_id = event.index
                last_look = event.position
        else:
            if event.position.x < get_viewport().get_visible_rect().size.x * 0.42:
                joystick_active = false
                joystick_vector = Vector2.ZERO
                joy_knob.position = Vector2(46, 46)
            if event.index == look_touch_id:
                look_touch_id = -1
    elif event is InputEventScreenDrag:
        if joystick_active and event.position.x < get_viewport().get_visible_rect().size.x * 0.48:
            _update_joystick(event.position)
        elif event.index == look_touch_id:
            var delta_pos := event.position - last_look
            yaw -= delta_pos.x * 0.006
            pitch = clamp(pitch - delta_pos.y * 0.003, -0.65, 0.25)
            last_look = event.position

func _update_joystick(pos: Vector2) -> void:
    var v := (pos - joystick_origin) / 58.0
    joystick_vector = Vector2(v.x, v.y).limit_length(1.0)
    joy_knob.position = Vector2(46, 46) + joystick_vector * 42.0

func _jump() -> void:
    if hero and hero.is_on_floor():
        hero.velocity.y = 7.2

func _fire_arrow() -> void:
    if not hero:
        return
    var arrow := Area3D.new()
    arrow.name = "Arrow"
    var mesh := MeshInstance3D.new()
    var cylinder := CylinderMesh.new()
    cylinder.top_radius = 0.025
    cylinder.bottom_radius = 0.025
    cylinder.height = 0.8
    mesh.mesh = cylinder
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.75, 0.56, 0.25)
    mesh.material_override = mat
    mesh.rotation_degrees.x = 90
    arrow.add_child(mesh)
    var collision := CollisionShape3D.new()
    var sphere := SphereShape3D.new()
    sphere.radius = 0.35
    collision.shape = sphere
    arrow.add_child(collision)
    var forward := -camera_pivot.global_transform.basis.z
    arrow.global_position = hero.global_position + Vector3.UP * 1.55 + forward * 1.0
    arrow.rotation = camera_pivot.global_rotation
    add_child(arrow)
    var tween := create_tween()
    tween.tween_property(arrow, "global_position", arrow.global_position + forward * 28.0, 0.65)
    tween.finished.connect(func():
        if is_instance_valid(arrow):
            if target and arrow.global_position.distance_to(target.global_position + Vector3.UP * 2.2) < 3.0:
                mission_done = true
                _set_status("TARGET HIT! Archery practice complete. Reach the shrine to finish the mission.")
            arrow.queue_free()
    )

func _check_shrine() -> void:
    if hero.global_position.distance_to(Vector3(0, 0, -43)) < 9.0:
        if mission_done:
            _set_status("MISSION COMPLETE! Jai Shri Ram. Forest shrine reached.")
        else:
            _set_status("Reach the training target first. Move toward the red target and press SHOOT.")
    else:
        _set_status("Follow the stone path to the forest shrine. The red target is your archery test.")
