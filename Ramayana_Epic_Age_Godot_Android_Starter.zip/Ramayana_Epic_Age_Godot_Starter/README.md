# RAMAYANA: THE EPIC AGE — Godot Android starter

This is a small, self-contained Godot 4 GDScript 3D prototype intended to be opened in the Godot Android Editor. It creates a procedural forest scene, a stylized placeholder hero, touch joystick, camera-look drag, jump and shoot buttons, a training target, and a shrine objective.

## Phone-only workflow
1. Install the official **Godot Engine Android Editor** from https://godotengine.org/download/android/ (choose the arm64 APK if installing directly; the Play Store version is also available where listed).
2. Launch it and grant its requested file access permission.
3. Download and extract `Ramayana_Epic_Age_Godot_Starter.zip` into a folder such as `Documents/Godot/Ramayana_Epic_Age`.
4. In Godot Android Editor, choose **Import** and select the extracted `project.godot`.
5. Open the project, wait for the first import, then press **Run Project** (triangle).
6. Test: left bottom joystick moves; drag the right side to rotate camera; SHOOT fires; JUMP jumps; SHRINE checks mission progress.
7. To export, use Project > Export and add Android if your installed editor build exposes Android export. Select APK, arm64, package ID `com.ramayana.epicage`, then export. On current Android editor builds, prebuilt APK export is supported without separately installing Android SDK/JDK; if your editor build does not show Android export, update to the latest official Android editor build. See https://docs.godotengine.org/en/latest/tutorials/export/exporting_for_android.html.

## Prototype limitations
- The hero is a simple colored capsule placeholder, not an authentic character model.
- Trees, shrine and target are procedural primitive meshes.
- No audio, enemy AI, save system, quest dialogue, or full open world yet.
- This is a starter prototype, not a finished commercial-quality game.
- Performance and APK export must be tested on the actual phone. Start with the Compatibility renderer and modest 3D settings.
